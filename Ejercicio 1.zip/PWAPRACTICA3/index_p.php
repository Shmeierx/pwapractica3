<?php
$productos = array(
    array("id" => 1, "nombre" => "MacBook Pro", "imagen" => "MacBookPro.png", "descripcion" => "La nueva MacBook Pro cuenta con un procesador M2, una pantalla Liquid Retina XDR y una batería de larga duración.", "precio" => 2500),
    array("id" => 2, "nombre" => "iPhone_14_Pro_Max", "imagen" => "iPhone14ProMax.png", "descripcion" => "El nuevo iPhone 14 Pro Max cuenta con una pantalla OLED ProMotion de 6,7 pulgadas, un sistema de triple cámara y un chip A16 Bionic.", "precio" => 1500),
    array("id" => 3, "nombre" => "Apple Watch Series 8", "imagen" => "AppleWatch.png", "descripcion" => "El nuevo Apple Watch Series 8 cuenta con una pantalla OLED más grande, un chip S8 más rápido y una resistencia al agua mejorada.", "precio" => 500),

);
?> 

<!DOCTYPE html>
<html lang="es">
<head>
    <title>Menú desplegable</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<h1>Lista de Productos</h1>
    <div id="listaProductos">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Imagen</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Descripcion</th>
                    <th scope="col">Precio</th>
                    <th scope="col">Agregar</th>
                </tr>
            </thead>
            <tbody>
                <?php for($i = 0; $i < count($productos); $i++) { ?>
                <tr>
                    <td><img src="<?php echo $productos[$i]["imagen"];?>" alt="<?php echo $productos[$i]["descripcion"];?>" style="width: 100px; height: 100px;"></td>
                    <td><?php echo $productos[$i]["nombre"];?></td>
                    <td><?php echo $productos[$i]["descripcion"];?></td>
                    <td>$<?php echo $productos[$i]["precio"];?></td>
                    <td><button class="btn btn-primary" onclick="agregarAlCarrito(<?php echo $productos[$i]['id']; ?>)">Agregar al carrito</button></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <div id="carrito">
        <h2>Carrito de Compras</h2>
        <ul id="lista-carrito"></ul>
        <p id="total">Total: $0.00</p>
    </div>
    
<script type="text/javascript">
    let productos = <?php echo json_encode($productos, JSON_PRETTY_PRINT); ?>;
</script>
<script src="script.js"></script>
</body>
</html>