let carrito = [];

function agregarAlCarrito(id) {
    const producto = productos.find((producto) => producto.id === id);
    const estaEnCarrito = carrito.find((item) => item.id === id);
    actualizarCarrito();

    if (estaEnCarrito) {
        alert('Este producto ya ha sido añadido al carrito.');
    } else {
        carrito.push(producto);
        mostrarCarrito();
    }    
}

function actualizarCarrito() {
    const listaCarrito = document.getElementById('lista-carrito');
    const totalElement = document.getElementById('total');

    listaCarrito.innerHTML = '';

    let total = 0;

    carrito.forEach(item => {
        const listItem = document.createElement('li');
        listItem.innerHTML = `${item.nombre} - $${item.precio.toFixed(2)}`;
        listaCarrito.appendChild(listItem);

        total += item.precio;
    });

    totalElement.textContent = `Total: $${total.toFixed(2)}`;
}

function mostrarCarrito() {
    const carritoItems = document.getElementById('carritoItems');
    carritoItems.innerHTML = '';
    
    carrito.forEach((producto) => {
        carritoItems.innerHTML += `
                <div class="col">
                    <button class="btn btn-danger" onclick="eliminarDelCarrito(${producto.id})">Eliminar</button>
                </div>
            </div>`;
    });
}

function eliminarDelCarrito(id) {
    carrito = carrito.filter((producto) => producto.id !== id);
    mostrarCarrito();
}